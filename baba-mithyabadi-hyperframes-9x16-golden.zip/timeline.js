(async function initHyperFramesTimeline() {
  await document.fonts.ready;

  const tl = gsap.timeline({ paused: true });
  const CUES = [{"id": 1, "start": 0.0}, {"id": 2, "start": 3.12}, {"id": 3, "start": 4.95}, {"id": 4, "start": 9.69}, {"id": 5, "start": 14.97}, {"id": 6, "start": 18.73}, {"id": 7, "start": 24.58}, {"id": 8, "start": 31.33}, {"id": 9, "start": 38.37}, {"id": 10, "start": 44.19}, {"id": 11, "start": 52.37}, {"id": 12, "start": 55.78}, {"id": 13, "start": 61.89}, {"id": 14, "start": 65.01}, {"id": 15, "start": 71.14}, {"id": 16, "start": 76.68}, {"id": 17, "start": 80.13}, {"id": 18, "start": 86.28}, {"id": 19, "start": 91.79}, {"id": 20, "start": 99.07}, {"id": 21, "start": 106.04}, {"id": 22, "start": 108.8}, {"id": 23, "start": 112.46}, {"id": 24, "start": 116.51}, {"id": 25, "start": 118.89}, {"id": 26, "start": 125.05}, {"id": 27, "start": 132.65}, {"id": 28, "start": 137.54}, {"id": 29, "start": 141.74}, {"id": 30, "start": 144.86}, {"id": 31, "start": 151.9}, {"id": 32, "start": 154.63}, {"id": 33, "start": 157.97}, {"id": 34, "start": 164.22}, {"id": 35, "start": 169.78}];

  // Subtle 3-property entrance for all 35 subtitle cards at exact SRT timestamps
  CUES.forEach((cue) => {
    const card = `#sub-${cue.id} .subtitle-card`;
    tl.fromTo(
      card,
      { y: 24, scale: 0.96, autoAlpha: 0 },
      { y: 0, scale: 1, autoAlpha: 1, duration: 0.34, ease: "power3.out" },
      cue.start
    );
  });

  // =========================================================================
  // SCENE 1: VILLAIN FATHER HOOK (0.00s - 14.97s)
  // =========================================================================
  tl.fromTo("#cam-villain", { scale: 1.0, x: 0, y: 0 }, { scale: 1.34, x: 18, y: -35, duration: 14.97, ease: "sine.inOut" }, 0);
  tl.to("#noir-bars", { y: 45, duration: 14.97, ease: "none" }, 0);
  tl.to("#villain-aura", { scale: 1.12, svgOrigin: "720 890", duration: 2.4, repeat: 5, yoyo: true, ease: "sine.inOut" }, 0);

  // Stamp #1: আস্ত মিথ্যাবাদী! + Micro camera shake at 0.35s
  tl.fromTo(
    "#stamp-liar",
    { scale: 2.1, rotation: -14, autoAlpha: 0, svgOrigin: "540 554" },
    { scale: 1.0, rotation: -8, autoAlpha: 1, duration: 0.38, ease: "power4.in" },
    0.35
  );
  tl.to("#cam-villain", { x: "+=10", duration: 0.05, repeat: 5, yoyo: true, ease: "none" }, 0.72);
  tl.to("#stamp-liar", { autoAlpha: 0, scale: 0.92, duration: 0.3, ease: "power2.in" }, 4.7);

  // Stamp #2: আসল চেহারা ফাঁস at 10.0s
  tl.fromTo(
    "#stamp-reveal",
    { scale: 2.0, rotation: 9, autoAlpha: 0, svgOrigin: "540 554" },
    { scale: 1.0, rotation: -5, autoAlpha: 1, duration: 0.38, ease: "power4.in" },
    10.0
  );
  tl.to("#cam-villain", { x: "+=10", duration: 0.05, repeat: 5, yoyo: true, ease: "none" }, 10.37);

  // =========================================================================
  // SCENE 2: LIE #1 - SNEAKERS vs PATCHED SANDAL (14.97s - 38.37s)
  // =========================================================================
  tl.fromTo("#cam-sandals", { scale: 1.0, x: 0, y: 0 }, { scale: 1.15, x: -35, y: 20, duration: 9.5, ease: "power2.out" }, 14.97);
  tl.to("#cam-sandals", { scale: 1.38, x: 65, y: -30, duration: 6.5, ease: "power3.inOut" }, 31.33);

  tl.fromTo("#card-sneaker", { y: 30, scale: 0.8, autoAlpha: 0, svgOrigin: "290 555" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.55, ease: "back.out(1.4)" }, 18.73);
  tl.to("#sneaker-star", { rotation: 180, scale: 1.25, svgOrigin: "385 500", duration: 1.5, repeat: 11, yoyo: true, ease: "sine.inOut" }, 18.8);

  tl.fromTo("#card-sandal", { y: 30, scale: 0.8, autoAlpha: 0, svgOrigin: "790 555" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.55, ease: "back.out(1.4)" }, 24.58);
  tl.fromTo("#bubble-son-shoe", { y: 22, scale: 0.85, autoAlpha: 0, svgOrigin: "370 760" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.42, ease: "back.out(1.5)" }, 25.0);
  tl.to("#bubble-son-shoe", { autoAlpha: 0, duration: 0.25 }, 31.0);
  tl.fromTo("#bubble-father-shoe", { y: 22, scale: 0.85, autoAlpha: 0, svgOrigin: "695 760" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.42, ease: "back.out(1.5)" }, 31.6);

  // =========================================================================
  // SCENE 3: LIE #2 - LUNCH TABLE & ARCING FISH (38.37s - 55.78s)
  // =========================================================================
  tl.fromTo("#cam-lunch", { scale: 1.0, x: 0, y: 0 }, { scale: 1.26, x: 45, y: -15, duration: 13.0, ease: "sine.inOut" }, 38.37);
  tl.to("#fish-arc-path", { strokeDashoffset: 0, duration: 1.2, ease: "power2.out" }, 44.3);

  // Parabolic arc motion for fish piece (X linear + Y up then down)
  tl.to("#fish-piece", { x: -420, rotation: -12, duration: 1.5, ease: "power2.inOut" }, 44.5);
  tl.to("#fish-piece", { y: -155, duration: 0.75, ease: "power2.out" }, 44.5);
  tl.to("#fish-piece", { y: 0, duration: 0.75, ease: "power2.in" }, 45.25);
  tl.fromTo("#bubble-father-lunch", { y: 20, scale: 0.85, autoAlpha: 0, svgOrigin: "690 770" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.45, ease: "back.out(1.5)" }, 45.8);

  // =========================================================================
  // SCENE 4: MIDNIGHT DOORWAY & TICKING 2:00 AM CLOCK (55.78s - 76.68s)
  // =========================================================================
  tl.fromTo("#cam-doorway", { scale: 1.0, x: 0, y: 0 }, { scale: 1.52, x: 35, y: -25, duration: 20.9, ease: "power1.inOut" }, 55.78);
  tl.to("#clock-second", { rotation: 360 * 3, svgOrigin: "0 0", duration: 20.9, ease: "none" }, 55.78);
  tl.to("#door-beam", { opacity: 0.24, duration: 4.5, ease: "power2.out" }, 65.01);
  tl.to("#scene-doorway .dust-mote", { y: -120, x: 18, duration: 20.9, stagger: 0.4, ease: "sine.inOut" }, 55.78);

  // =========================================================================
  // SCENE 5: MIDNIGHT LEDGER & LIVE TAKA COUNTERS (76.68s - 86.28s)
  // =========================================================================
  tl.fromTo("#cam-ledger", { scale: 1.0, x: 0, y: 0 }, { scale: 1.18, x: 20, y: -18, duration: 9.6, ease: "sine.inOut" }, 76.68);
  tl.fromTo("#insert-ledger", { y: 45, rotation: -5, scale: 0.82, autoAlpha: 0, svgOrigin: "540 680" }, { y: 0, rotation: -2.2, scale: 1, autoAlpha: 1, duration: 0.55, ease: "back.out(1.3)" }, 76.8);
  tl.to("#scene-ledger .ledger-row", { autoAlpha: 1, y: 0, duration: 0.4, stagger: 0.55, ease: "power2.out" }, 77.3);

  // Live ticking numeric counters
  const counters = { college: 0, coaching: 0, bills: 0 };
  const elCol = document.getElementById("val-college");
  const elCoa = document.getElementById("val-coaching");
  const elBil = document.getElementById("val-bills");
  tl.to(counters, {
    college: 4500,
    duration: 1.1,
    ease: "power2.out",
    onUpdate: () => { if (elCol) elCol.textContent = "৳ " + Math.round(counters.college).toLocaleString(); },
  }, 77.3);
  tl.to(counters, {
    coaching: 3000,
    duration: 1.1,
    ease: "power2.out",
    onUpdate: () => { if (elCoa) elCoa.textContent = "৳ " + Math.round(counters.coaching).toLocaleString(); },
  }, 77.85);
  tl.to(counters, {
    bills: 8200,
    duration: 1.1,
    ease: "power2.out",
    onUpdate: () => { if (elBil) elBil.textContent = "৳ " + Math.round(counters.bills).toLocaleString(); },
  }, 78.4);

  // =========================================================================
  // SCENE 6: EMPTY WALLET (86.28s - 91.79s)
  // =========================================================================
  tl.fromTo("#cam-wallet", { scale: 1.0 }, { scale: 1.14, duration: 5.51, ease: "sine.inOut" }, 86.28);
  tl.fromTo("#insert-wallet", { y: 45, scale: 0.82, rotation: 3, autoAlpha: 0, svgOrigin: "540 675" }, { y: 0, scale: 1, rotation: -2, autoAlpha: 1, duration: 0.5, ease: "back.out(1.3)" }, 86.4);
  tl.to("#wallet-notes", { y: -12, duration: 1.2, repeat: 3, yoyo: true, ease: "sine.inOut" }, 86.9);

  // =========================================================================
  // SCENE 7: FOLDING PRESCRIPTION (91.79s - 106.04s)
  // =========================================================================
  tl.fromTo("#cam-rx", { scale: 1.0 }, { scale: 1.26, x: 25, y: -20, duration: 14.25, ease: "sine.inOut" }, 91.79);
  tl.fromTo("#insert-rx", { y: 45, scale: 0.82, rotation: -3, autoAlpha: 0, svgOrigin: "540 680" }, { y: 0, scale: 1, rotation: -1.8, autoAlpha: 1, duration: 0.5, ease: "back.out(1.3)" }, 91.9);
  tl.fromTo("#rx-stamp", { scale: 1.7, rotation: -10, autoAlpha: 0, svgOrigin: "540 763" }, { scale: 1, rotation: -5, autoAlpha: 1, duration: 0.35, ease: "power4.in" }, 95.0);
  // Fold & slide prescription into pocket
  tl.to("#insert-rx", { scaleY: 0.42, y: 185, opacity: 0.85, svgOrigin: "540 680", duration: 1.4, ease: "power3.inOut" }, 97.2);

  // =========================================================================
  // SCENE 8: TRUTH REALIZATIONS (106.04s - 125.05s)
  // =========================================================================
  tl.fromTo("#cam-truths", { scale: 1.0 }, { scale: 1.12, y: -12, duration: 19.01, ease: "sine.inOut" }, 106.04);
  tl.fromTo("#truth-card-1", { y: 30, scale: 0.88, autoAlpha: 0, svgOrigin: "540 467" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.5, ease: "back.out(1.3)" }, 108.8);
  tl.fromTo("#truth-card-2", { y: 30, scale: 0.88, autoAlpha: 0, svgOrigin: "540 589" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.5, ease: "back.out(1.3)" }, 116.51);
  tl.fromTo("#truth-card-3", { y: 30, scale: 0.88, autoAlpha: 0, svgOrigin: "540 711" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.5, ease: "back.out(1.3)" }, 121.0);

  // =========================================================================
  // SCENE 9: PARALLAX WALK HOME (125.05s - 137.54s)
  // =========================================================================
  tl.fromTo("#cam-walk", { scale: 1.0 }, { scale: 1.2, y: -25, duration: 12.49, ease: "sine.inOut" }, 125.05);
  tl.to("#parallax-far", { x: -420, duration: 12.49, ease: "none" }, 125.05);
  tl.to("#parallax-mid", { x: -860, duration: 12.49, ease: "none" }, 125.05);
  tl.to("#parallax-near", { x: -1260, duration: 12.49, ease: "none" }, 125.05);

  // Deterministic finite walk cycle (24 half-steps over 12.49s)
  tl.to("#walk-father .leg-left", { rotation: 24, svgOrigin: "-16 250", duration: 0.26, repeat: 47, yoyo: true, ease: "sine.inOut" }, 125.05);
  tl.to("#walk-father .leg-right", { rotation: -24, svgOrigin: "16 250", duration: 0.26, repeat: 47, yoyo: true, ease: "sine.inOut" }, 125.05);
  tl.to("#walk-father .char-arm", { rotation: -22, svgOrigin: "8 138", duration: 0.26, repeat: 47, yoyo: true, ease: "sine.inOut" }, 125.05);
  tl.to("#walk-father .char-body", { y: -12, duration: 0.26, repeat: 47, yoyo: true, ease: "sine.inOut" }, 125.05);
  tl.fromTo("#bubble-walk", { y: 24, scale: 0.85, autoAlpha: 0, svgOrigin: "540 638" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.45, ease: "back.out(1.4)" }, 132.7);

  // =========================================================================
  // SCENE 10: UNIVERSAL REFRAME CARD (137.54s - 151.90s)
  // =========================================================================
  tl.fromTo("#cam-reframe", { scale: 1.0 }, { scale: 1.1, duration: 14.36, ease: "sine.inOut" }, 137.54);
  tl.fromTo("#reframe-card-box", { y: 36, scale: 0.9, autoAlpha: 0, svgOrigin: "540 820" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.65, ease: "power3.out" }, 137.7);

  // =========================================================================
  // SCENE 11: QUIET VOW (151.90s - 164.22s)
  // =========================================================================
  tl.fromTo("#cam-vow", { scale: 1.16, y: -15 }, { scale: 1.0, y: 0, duration: 12.32, ease: "power2.out" }, 151.90);
  tl.fromTo("#vow-badge", { y: 24, scale: 0.85, autoAlpha: 0, svgOrigin: "540 598" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.55, ease: "back.out(1.4)" }, 158.1);

  // =========================================================================
  // SCENE 12: OUTRO CTA (164.22s - 175.00s)
  // =========================================================================
  tl.fromTo("#cam-outro", { scale: 1.0 }, { scale: 1.06, duration: 10.78, ease: "sine.inOut" }, 164.22);
  tl.fromTo("#outro-card-box", { y: 36, scale: 0.9, autoAlpha: 0, svgOrigin: "540 820" }, { y: 0, scale: 1, autoAlpha: 1, duration: 0.65, ease: "power3.out" }, 164.4);

  // Register finite seekable timeline for HyperFrames
  window.__timelines = window.__timelines || {};
  window.__timelines["baba-mithyabadi"] = tl;
})();
